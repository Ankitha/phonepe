package com.example.geektrust.vo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CardDetails {

    private String cardNumber;

    private String cvv;

    private String expiryYear;

    private String expiryMonth;
}
