package com.example.geektrust.vo;

public enum PaymentMethod {

    CREDIT_CARD, DEBIT_CARD, UPI, NETBANKING
}
