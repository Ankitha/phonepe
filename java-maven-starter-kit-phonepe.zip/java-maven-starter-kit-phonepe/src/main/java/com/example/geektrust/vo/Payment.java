package com.example.geektrust.vo;

public class Payment {

    public void makePayment(PaymentMode paymentMode){
        String pay = paymentMode.getPaymentMode();
        switch(PaymentMethod.valueOf(pay)){
            case CREDIT_CARD : {
                System.out.println("Credit card payment is successful");
                break;
            }
            case DEBIT_CARD : {
                System.out.println("Debit card payment is successful");
                break;
            }
            case UPI : {
                System.out.println("UPI payment is successful");
                break;
            }
            case NETBANKING: {
                System.out.println("NetBanking payment is successful");
                break;
            }
            default:{
                System.out.println("Invalid payment method");
                break;
            }

        }
    }
}
