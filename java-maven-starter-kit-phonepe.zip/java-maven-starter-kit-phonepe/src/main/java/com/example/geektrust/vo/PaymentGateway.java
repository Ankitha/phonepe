package com.example.geektrust.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PaymentGateway {

    private int id;
    private String paymentGatewayName;
    private List<Client> clientName = new ArrayList<>();

    public void addClient(Client client){
        if(hasClient(client.getClientId())){
            System.out.println("Client already present inside the list");
        } else {
            clientName.add(client);
            System.out.println("Client added to the list");
        }
    }

    public boolean hasClient(int clientId){
        return clientName.contains(clientId);
    }


    public void removeClient(int clientId){
        if(clientId != 0){
            for(Client obj : clientName){
                if(obj.getClientId()==clientId){
                    clientName.remove(clientId);
                }
            }
        } else {
            System.out.println("Invalid client Id passed");
        }

    }


    public List<PaymentMode> listSupportedPaymentModes(int clientId){
        List<PaymentMode> paymentModes = new ArrayList<>();
        for(Client obj : clientName){
            if(obj.getClientId() == clientId){
                paymentModes= obj.getPaymentModeList();
            }
        }
        return paymentModes;
    }

    public void printAllClients(){
        System.out.println("Payment Gateway ----------------------------"+ paymentGatewayName);
        for(Client obj:clientName){
            System.out.println("*****************************");
            System.out.println("Client ID -"+obj.getClientId());
            System.out.println("Client Name -"+obj.getClientName());
            System.out.println("*****************************");
            System.out.println();
        }
    }
}
