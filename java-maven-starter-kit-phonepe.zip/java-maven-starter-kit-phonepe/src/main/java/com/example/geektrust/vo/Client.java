package com.example.geektrust.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Client {

    private String clientName;

    private int clientId;

    private List<PaymentMode> paymentModeList = new ArrayList<>();

    public void addSupportForPaymentMode(PaymentMode paymentMode){
        if(paymentModeList!= null && paymentModeList.contains(paymentMode)){
            System.out.println("This payment mode is already existing");
        } else {
            paymentModeList.add(paymentMode);
            System.out.println("This payment mode is added successfully");
        }
    }

    public void removePaymentMode(PaymentMode paymentMode){
        if(paymentModeList.contains(paymentMode)){
            paymentModeList.remove(paymentMode);
            System.out.println("This payment mode is removed successfully");
        } else {
            System.out.println("This payment mode is not present");
        }
    }

}
