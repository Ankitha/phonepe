package com.example.geektrust;

import com.example.geektrust.vo.Client;
import com.example.geektrust.vo.PaymentGateway;
import com.example.geektrust.vo.PaymentMode;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        PaymentGateway razorPay = new PaymentGateway();
        razorPay.setPaymentGatewayName("RAZORPAY");
        razorPay.setId(101);

        Client flipkart = new Client();
        flipkart.setClientId(1);
        flipkart.setClientName("Flipkart");
        PaymentMode creditCardPayment = new PaymentMode("CREDIT_CARD");
        flipkart.addSupportForPaymentMode(creditCardPayment);
        PaymentMode debitCardPayment = new PaymentMode("DEBIT_CARD");
        flipkart.addSupportForPaymentMode(debitCardPayment);
        razorPay.addClient(flipkart);

        Client amazon = new Client();
        amazon.setClientId(2);
        amazon.setClientName("Amazon");
        PaymentMode creditCardPaymentForAmazon = new PaymentMode("CREDIT_CARD");
        amazon.addSupportForPaymentMode(creditCardPaymentForAmazon);
        PaymentMode debitCardPaymentForAmazon = new PaymentMode("DEBIT_CARD");
        amazon.addSupportForPaymentMode(debitCardPaymentForAmazon);
        razorPay.addClient(amazon);

        Client myntra = new Client();
        myntra.setClientId(3);
        myntra.setClientName("Myntra");
        PaymentMode creditCardPaymentForMyntra = new PaymentMode("CREDIT_CARD");
        myntra.addSupportForPaymentMode(creditCardPaymentForMyntra);
        PaymentMode debitCardPaymentForMyntra = new PaymentMode("DEBIT_CARD");
        myntra.addSupportForPaymentMode(debitCardPaymentForMyntra);
        myntra.removePaymentMode(creditCardPaymentForMyntra);
        razorPay.addClient(myntra);

        PaymentGateway jusPay = new PaymentGateway();
        jusPay.setPaymentGatewayName("JUS PAY");
        jusPay.setId(102);
        Client ajio = new Client();
        ajio.setClientId(11);
        PaymentMode creditCardPaymentForAjio = new PaymentMode("UPI");
        ajio.addSupportForPaymentMode(creditCardPaymentForAjio);
        PaymentMode debitCardPaymentForAjio = new PaymentMode("NETBANKING");
        ajio.addSupportForPaymentMode(debitCardPaymentForAjio);
        ajio.setClientName("Ajio");

        jusPay.addClient(ajio);

        Client chumbak = new Client();
        chumbak.setClientId(12);
        chumbak.setClientName("Chumbak");
        jusPay.addClient(chumbak);

        razorPay.printAllClients();
        jusPay.printAllClients();

        System.out.println("RazorPay has client as Chumbak == "+razorPay.hasClient(12));



        List<PaymentMode> paymentModesForRazorPay =  razorPay.listSupportedPaymentModes(1);
        System.out.println(paymentModesForRazorPay.toString());

        List<PaymentMode> paymentModesForJusPay =  jusPay.listSupportedPaymentModes(11);
        System.out.println(paymentModesForJusPay.toString());

        List<PaymentMode> paymentModesForRazorPayMyntra =  razorPay.listSupportedPaymentModes(3);
        System.out.println(paymentModesForRazorPayMyntra.toString());





    }
}
